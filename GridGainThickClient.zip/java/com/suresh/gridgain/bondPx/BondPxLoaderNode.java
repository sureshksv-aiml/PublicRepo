package com.suresh.gridgain.bondPx;

import java.io.FileReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.MapUtils;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteDataStreamer;
import org.apache.ignite.lang.IgniteFuture;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

import com.opencsv.bean.CsvToBeanBuilder;
import com.suresh.gridgain.miniBond.MiniBond;
	
public class BondPxLoaderNode {

	public static void main(String[] args) {
		System.setProperty("IGNITE_EVENT_DRIVEN_SERVICE_PROCESSOR_ENABLED", "true");
		
		// Connect to the cluster
		try {
				
			ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("clientNode.xml");
			Ignite client = (Ignite) ctx.getBean("clientNode");
 
			Map<String, BondPx> bondPxMap = loadBondPx();
			
			  IgniteCache<String, BondPx> bondPxCache = client.getOrCreateCache("bondPxCache");
			  System.out.println("Got the BondPx cache"); 
			 // bondCache.putAll(BondPxMap);
			  
			  try (IgniteDataStreamer<String, BondPx> stmr = client.dataStreamer(bondPxCache.getName())) {
                  // Allow data updates.
                  stmr.allowOverwrite(true);
                  stmr.addData(bondPxMap);
              
              }
			 System.out.println("Put the bond Px data Complete");
			 
				
				
 
 
		}
		
		catch (Exception e) {
			e.printStackTrace();
			
		}
		
		finally {
			
		}

	}
	
	private static Map<String, BondPx> loadBondPx() throws Exception
	{
		  List<BondPx> beans = new CsvToBeanBuilder(new FileReader(new ClassPathResource("bond_px_sample.csv").getFile()))
	                .withType(BondPx.class)
	                .build()
	                .parse();

	        Map<String, BondPx> BondPxMap = new HashMap<>();
	        MapUtils.populateMap(BondPxMap, beans, BondPx::getCusip);
	        System.out.println("Bond Pxs loaded Size:"+BondPxMap.keySet().size());
	        return BondPxMap;
		
	}

}
