package com.suresh.gridgain.bondPx;

import com.opencsv.bean.CsvBindByName;


public class BondPx {
	
	@CsvBindByName(column = "CUSIP")
    private String cusip;
	
	@CsvBindByName(column = "TRADED_PAR")
    private Integer tradedPar;
	
	@CsvBindByName(column = "PX")
    private Double px;
	
	@CsvBindByName(column = "YLD")
    private Double yld;

	public String getCusip() {
		return cusip;
	}

	public void setCusip(String cusip) {
		this.cusip = cusip;
	}

	public Integer getTradedPar() {
		return tradedPar;
	}

	public void setTradedPar(Integer tradedPar) {
		this.tradedPar = tradedPar;
	}

	public Double getPx() {
		return px;
	}

	public void setPx(Double px) {
		this.px = px;
	}

	public Double getYld() {
		return yld;
	}

	public void setYld(Double yld) {
		this.yld = yld;
	}

	@Override
	public String toString() {
		return "BondPx [cusip=" + cusip + ", tradedPar=" + tradedPar + ", px=" + px + ", yld=" + yld + "]";
	}
	
	
	
	

   }
