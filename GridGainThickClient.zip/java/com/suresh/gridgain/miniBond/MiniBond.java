package com.suresh.gridgain.miniBond;

import com.opencsv.bean.CsvBindByName;


public class MiniBond {
	
	@CsvBindByName(column = "CUSIP")
    private String cusip;

    @CsvBindByName(column = "DAYS_TO_MATURE")
    private Integer daysToMature;

    @CsvBindByName(column = "CPN")
    private Double coupon;

    @CsvBindByName(column = "B_RTG_SP")
    private String bbgRtg;
    
    @CsvBindByName(column = "STATE_CODE")
    private String state;
    
    @CsvBindByName(column = "BLOOMBERG_SECTOR_CODE")
    private String bbgSectorCode;
    
    @CsvBindByName(column = "MUNI_ISSUE_TYP")
    private String issuerType;
    
    @CsvBindByName(column = "FED_TAXABLE")
    private Boolean taxable;
    
    @CsvBindByName(column = "CALLABLE")
    private Boolean callable;
    
    @CsvBindByName(column = "SINKABLE")
    private Boolean sinkable;
    
    @CsvBindByName(column = "PUTABLE")
    private Boolean putable;

	public String getCusip() {
		return cusip;
	}

	public void setCusip(String cusip) {
		this.cusip = cusip;
	}

	public Integer getDaysToMature() {
		return daysToMature;
	}

	public void setDaysToMature(Integer daysToMature) {
		this.daysToMature = daysToMature;
	}

	public Double getCoupon() {
		return coupon;
	}

	public void setCoupon(Double coupon) {
		this.coupon = coupon;
	}

	public String getBbgRtg() {
		return bbgRtg;
	}

	public void setBbgRtg(String bbgRtg) {
		this.bbgRtg = bbgRtg;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getBbgSectorCode() {
		return bbgSectorCode;
	}

	public void setBbgSectorCode(String bbgSectorCode) {
		this.bbgSectorCode = bbgSectorCode;
	}

	public String getIssuerType() {
		return issuerType;
	}

	public void setIssuerType(String issuerType) {
		this.issuerType = issuerType;
	}

	public Boolean getTaxable() {
		return taxable;
	}

	public void setTaxable(Boolean taxable) {
		this.taxable = taxable;
	}

	public Boolean getCallable() {
		return callable;
	}

	public void setCallable(Boolean callable) {
		this.callable = callable;
	}

	public Boolean getSinkable() {
		return sinkable;
	}

	public void setSinkable(Boolean sinkable) {
		this.sinkable = sinkable;
	}

	public Boolean getPutable() {
		return putable;
	}

	public void setPutable(Boolean putable) {
		this.putable = putable;
	}

	@Override
	public String toString() {
		return "MiniBond [cusip=" + cusip + ", daysToMature=" + daysToMature + ", coupon=" + coupon + ", bbgRtg="
				+ bbgRtg + ", state=" + state + ", bbgSectorCode=" + bbgSectorCode + ", issuerType=" + issuerType
				+ ", taxable=" + taxable + ", callable=" + callable + ", sinkable=" + sinkable + ", putable=" + putable
				+ "]";
	}

	
	

}
