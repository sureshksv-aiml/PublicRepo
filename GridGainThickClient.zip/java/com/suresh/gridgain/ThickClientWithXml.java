package com.suresh.gridgain;

import java.util.Collections;

import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.Ignition;
import org.apache.ignite.configuration.CacheConfiguration;
import org.apache.ignite.configuration.IgniteConfiguration;
import org.apache.ignite.plugin.security.SecurityCredentials;
import org.apache.ignite.plugin.security.SecurityCredentialsBasicProvider;
import org.apache.ignite.spi.communication.tcp.TcpCommunicationSpi;
import org.apache.ignite.spi.discovery.tcp.TcpDiscoverySpi;
import org.apache.ignite.spi.discovery.tcp.ipfinder.vm.TcpDiscoveryVmIpFinder;
import org.apache.ignite.ssl.SslContextFactory;
import org.gridgain.grid.configuration.GridGainConfiguration;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ThickClientWithXml {

	public static void main(String[] args) {
		System.setProperty("IGNITE_EVENT_DRIVEN_SERVICE_PROCESSOR_ENABLED", "true");
		/*
		 * SecurityCredentials clientCredentials = new
		 * SecurityCredentials("cluster-user", "suresh123"); IgniteConfiguration cfg =
		 * new IgniteConfiguration() .setClientMode(true) .setDiscoverySpi(new
		 * TcpDiscoverySpi() .setIpFinder(new TcpDiscoveryVmIpFinder()
		 * .setAddresses(Collections.singleton(
		 * "0501c0db-11ca-44a3-b177-0b8f19b5aeab.gridgain-nebula.com:47500"))))
		 * .setCommunicationSpi(new TcpCommunicationSpi()
		 * .setForceClientToServerConnections(true) ) .setPluginConfigurations(new
		 * GridGainConfiguration() .setSecurityCredentialsProvider(new
		 * SecurityCredentialsBasicProvider(clientCredentials))
		 * .setRollingUpdatesEnabled(true)) .setSslContextFactory(new
		 * SslContextFactory());
		 */

		// Connect to the cluster
		try {
 ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("clientNode.xml");
 Ignite client = (Ignite) ctx.getBean("clientNode");
 
 IgniteCache<Integer, String> cache = client.getOrCreateCache(new
		  CacheConfiguration<Integer, String>() .setName("TestWithXml") .setBackups(1) ); for
		 (int i = 0; i < 150; i++) { cache.put(i, "foo"+i); }
		  
		  System.out.println(">>>    " + cache.get(149));
 
 /*
		try (Ignite client = Ignition.start("example-ignite.xml")) {
		    // Use the API.
			
			
			  IgniteCache<Integer, String> cache = client.getOrCreateCache(new
			  CacheConfiguration<Integer, String>() .setName("TestWithXml") .setBackups(1) ); for
			 (int i = 0; i < 150; i++) { cache.put(i, "foo"+i); }
			  
			  System.out.println(">>>    " + cache.get(1));
			 
		}*/
		}
		
		finally {
			
		}

	}

}
